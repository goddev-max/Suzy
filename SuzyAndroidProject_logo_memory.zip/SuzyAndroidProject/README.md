# Suzy AI — Android starter with logo and local profile

This project is styled around the supplied black/silver Suzy logo. It includes a basic native chat interface, local creator profile and note saving.

## Important current status
- This ZIP is Android source code, **not a compiled/installable APK**.
- Creator name and notes are stored locally on this device using Android preferences.
- Local note saving is memory storage, not neural-network training.
- The app does not yet have a connected general-purpose AI brain or live internet research backend. The server URL is a placeholder.
- No third-party AI API or pretrained model is included.

## Build
A compatible Android build environment (usually Android Studio on a computer, or a trusted cloud build workflow) is required to compile this source into an APK. After build, install the APK on the POCO X6 Neo.

## Connect a backend later
Set `serverEndpoint` in `MainActivity.kt` to your own HTTPS endpoint. The endpoint must accept POST JSON `{"message":"text"}` and return `{"reply":"text"}`. Never place private server credentials in the APK.
