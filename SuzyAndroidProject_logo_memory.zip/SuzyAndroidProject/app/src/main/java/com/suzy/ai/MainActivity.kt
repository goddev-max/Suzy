package com.suzy.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // Replace this with your own HTTPS server endpoint when Suzy's backend is ready.
    // Expected POST JSON: {"message":"..."}
    // Expected response JSON: {"reply":"..."}
    private val serverEndpoint = "https://YOUR-SUZY-SERVER.example/chat"
    private val prefs by lazy { getSharedPreferences("suzy_profile", MODE_PRIVATE) }

    private lateinit var conversation: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(12, 16, 30))
        }

        val title = TextView(this).apply {
            text = "SUZY AI"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 8)
        }
        val subtitle = TextView(this).apply {
            text = "Your personal assistant • Creator mode"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        conversation = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 16, 8, 16)
        }
        val scroll = ScrollView(this).apply {
            addView(conversation)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Message Suzy..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setBackgroundColor(Color.rgb(35, 42, 60))
            setPadding(14, 10, 14, 10)
        }
        sendButton = Button(this).apply {
            text = "Send"
            setOnClickListener { sendMessage() }
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(sendButton, LinearLayout.LayoutParams(-2, -2))

        page.addView(title)
        page.addView(subtitle)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(bottom)
        setContentView(page)

        val creator = prefs.getString("creator", "")
        if (creator.isNullOrBlank()) {
            addBubble("Suzy", "Hi! I’m Suzy. Who created me? Tell me your creator name.")
        } else {
            addBubble("Suzy", "Welcome back, $creator — my creator. I remember you on this device.")
        }
    }

    private fun addBubble(who: String, text: String) {
        val bubble = TextView(this).apply {
            this.text = "$who: $text"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(if (who == "You") Color.rgb(44, 78, 120) else Color.rgb(38, 45, 64))
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, 6, 0, 6)
        conversation.addView(bubble, params)
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return

        addBubble("You", message)
        input.setText("")
        sendButton.isEnabled = false

        val lower = message.lowercase()
        if (lower.startsWith("my name is ") || lower.startsWith("mera naam ") || lower.startsWith("i created you")) {
            val creatorName = when {
                lower.startsWith("my name is ") -> message.substringAfter("my name is ").trim()
                lower.startsWith("mera naam ") -> message.substringAfter("mera naam ").trim()
                else -> "Creator"
            }
            if (creatorName.isNotBlank()) {
                prefs.edit().putString("creator", creatorName).apply()
                addBubble("Suzy", "Got it, $creatorName. I’ll remember you as my creator on this phone.")
            } else addBubble("Suzy", "Tell me your creator name clearly.")
            sendButton.isEnabled = true
            return
        }
        if (lower.startsWith("remember ") || lower.startsWith("yaad rakh ")) {
            val fact = message.substringAfter(" ").trim()
            val old = prefs.getString("learned_notes", "") ?: ""
            prefs.edit().putString("learned_notes", (old + "\n" + fact).trim()).apply()
            addBubble("Suzy", "Saved locally on this phone. This stores a note; it does not retrain my neural network.")
            sendButton.isEnabled = true
            return
        }
        if (serverEndpoint.contains("YOUR-SUZY-SERVER")) {
            addBubble("Suzy", "I can save your creator profile and notes on this phone, but my AI brain/server is not connected yet. This chat needs a backend to answer general questions.")
            sendButton.isEnabled = true
            return
        }

        thread {
            val reply = try {
                val conn = (URL(serverEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("message", message).toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                JSONObject(body).optString("reply", "Server response had no 'reply' field.")
            } catch (e: Exception) {
                "Could not reach Suzy server: ${e.message ?: "unknown error"}"
            }

            runOnUiThread {
                addBubble("Suzy", reply)
                sendButton.isEnabled = true
            }
        }
    }
}
